<?php
include './header.php';
include './navbar.php';
?>


<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <h2 class="page-header">PHP</h2>


            <a href="post.php"><h3>What is PHP</h3> </a>
            <p>
                PHP (recursive acronym for PHP: Hypertext Preprocessor) is a widely-used open source general-purpose scripting language that is especially suited for web development and can be embedded into HTML.
                <a href="post.php">View More</a>
            </p>
            <br>
            <a href="post.php"><h3>Why is PHP</h3> </a>
            <p>
                PHP (recursive acronym for PHP: Hypertext Preprocessor) is a widely-used open source general-purpose scripting language that is especially suited for web development and can be embedded into HTML.
                <a href="post.php">View More</a>
            </p>
            
            <br>
            <a href="post.php"><h3>Web development using PHP</h3> </a>
            <p>
                PHP (recursive acronym for PHP: Hypertext Preprocessor) is a widely-used open source general-purpose scripting language that is especially suited for web development and can be embedded into HTML.
                <a href="post.php">View More</a>
            </p>
            
        </div>
    </div>
</div>


<?php
include './footer.php';

?>