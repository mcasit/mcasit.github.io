
    <!-- jQuery -->


            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


            <!-- jQuery -->


            <!-- Bootstrap v3 Javascript -->


            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

            <!-- Bootstrap v3 Javascript -->

    </body>

</html>
